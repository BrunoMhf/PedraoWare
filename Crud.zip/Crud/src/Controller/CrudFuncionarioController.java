package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;


public class CrudFuncionarioController implements Initializable {

	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

	}

	
	@FXML
    private TabPane abas;

    @FXML
    private Tab cadastrar;

    @FXML
    private TextField nomeNovoFuncionario;

    @FXML
    private DatePicker nascimentoNovoFuncionario;

    @FXML
    private TextField cargoNovoFuncionario;

    @FXML
    private TextField salarioNovoFuncionario;

    @FXML
    private Tab consultar;

    @FXML
    private TextField nomeConsultaFuncionario;

    @FXML
    private TableView<?> funcionarios;

    @FXML
    private TableColumn<?, ?> idFuncionarios;

    @FXML
    private TableColumn<?, ?> nomeFuncionarios;

    @FXML
    private TableColumn<?, ?> nascimentoFuncionarios;

    @FXML
    private TableColumn<?, ?> cargoFuncionarios;

    @FXML
    private TableColumn<?, ?> salarioFuncionarios;

    @FXML
    private Tab atualizar;

    @FXML
    private TextField nomeFuncionario;

    @FXML
    private DatePicker nascimentoFuncionario;

    @FXML
    private TextField cargoFuncionario;

    @FXML
    private TextField salarioFuncionario;

    @FXML
    void consultarFuncionarios(MouseEvent event) {

    }

    @FXML
    void deletaFuncionario(MouseEvent event) {

    }

    @FXML
    void exibirAbaAtualizacao(MouseEvent event) {

    }

    @FXML
    void gerenciarAbas(MouseEvent event) {

    }

    @FXML
    void limparCadastroNovoFuncionario(MouseEvent event) {

    }

    @FXML
    void salvarFuncionario(MouseEvent event) {

    }

    @FXML
    void salvarNovoFuncionario(MouseEvent event) {

    }

}
