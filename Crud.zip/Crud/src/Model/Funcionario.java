package Model;

public class Funcionario {

}
